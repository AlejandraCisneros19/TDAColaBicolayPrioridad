/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 52311
 */
public class Prioridad {
    
    protected Data[] cola = new Data[6];
    protected int ini=-1;
    protected int fin=-1;
    
    public Prioridad(){
        for(int i=0; i<cola.length; i++){
            cola[i]=new Data();
        }
    }
    
    public boolean insert(Data dato){
        if(fin==cola.length-1){
            return false;
        }
        fin++;
        cola[fin]=dato;
        if(ini==-1 && fin==0){
            ini++;
        }
        ordenarPrioridad();
        return true;
    }
    
    private void ordenarPrioridad(){
        if(fin==0){
            return;
        }
        for( int temp=fin; 
                temp!=ini && cola[temp].prioridad>cola[temp-1].prioridad;
                temp--){
            Data intercambio = new Data();
            int anterior=temp-1;
            
            intercambio.valor=cola[anterior].valor;
            intercambio.prioridad=cola[anterior].prioridad;
            
            cola[anterior].valor=cola[temp].valor;
            cola[anterior].prioridad=cola[temp].prioridad;
            
            cola[temp].valor=intercambio.valor;
            cola[temp].prioridad=intercambio.prioridad;
        }
    }
    
}
